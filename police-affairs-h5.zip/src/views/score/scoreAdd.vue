<script lang="ts" name="ScoreAdd" setup></script>

<template>
  <div class="container">ScoreAdd</div>
</template>

<style scoped></style>
