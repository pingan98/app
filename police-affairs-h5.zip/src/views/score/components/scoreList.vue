<script setup lang="ts" name="ScoreList">
import { ref } from "vue";
import ScoreCard from "@/views/score/components/scoreCard.vue";
// 加载中状态
const loading = ref(false);
// 是否完全加载完毕数据
const finished = ref(false);
</script>

<template>
  <div class="score-list page-list">
    <van-list finished-text="没有更多了">
      <score-card></score-card>
      <score-card></score-card>
    </van-list>
  </div>
</template>

<style scoped lang="less"></style>
