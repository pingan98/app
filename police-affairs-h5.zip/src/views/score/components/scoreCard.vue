<script lang="ts" name="ScoreCard"></script>

<template>
  <div
    class="page-list-item flex justify-start items-start van-hairline--bottom"
  >
    <div class="w-[45px] h-[45px] rounded-full">
      <img src="@/assets/avatar@3x.png" alt="" />
    </div>
    <div class="flex-1 pl-[20px]">
      <div class="flex justify-between">
        <span class="name text-[16px] font-bold">张张张</span>
        <span class="time">2023-07-30</span>
      </div>
      <div class="flex">
        <span class="flex justify-start items-center pr-[10px]"
          ><img
            src="@/assets/idcard_icon@3x.png"
            alt=""
            class="w-[16px] pr-[4px] box-content"
          />民警</span
        >
        <span class="flex justify-start items-center"
          ><img
            src="@/assets/dep_icon@3x.png"
            alt=""
            class="w-[14px] pr-[4px] box-content"
          />部门名称</span
        >
      </div>
    </div>
  </div>
</template>

<style scoped lang="less">
.name {
  color: var(--text-color1);
}
.time {
  color: var(--text-color2);
}
</style>
