<script setup lang="ts" name="NoPermission"></script>

<template>
  <div class="container">NoPermission</div>
</template>

<style scoped lang="scss"></style>
