<script setup lang="ts" name="NoFound"></script>

<template>
  <div class="container">NotFound</div>
</template>

<style scoped lang="scss"></style>
