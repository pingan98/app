<script setup lang="ts" name="Myself"></script>

<template>
  <div>myself</div>
</template>
